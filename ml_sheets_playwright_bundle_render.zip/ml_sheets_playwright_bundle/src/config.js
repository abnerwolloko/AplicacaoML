require('dotenv').config();

function env(name, fallback) {
  const value = process.env[name];
  return value === undefined || value === '' ? fallback : value;
}

module.exports = {
  port: Number(env('PORT', 8080)),
  apiKey: env('WORKER_API_KEY', ''),
  siteId: env('ML_SITE_ID', 'MLB'),
  playwright: {
    headless: String(env('PLAYWRIGHT_HEADLESS', 'true')).toLowerCase() !== 'false',
    timeoutMs: Number(env('PLAYWRIGHT_TIMEOUT_MS', 25000)),
  },
  limits: {
    maxInputs: Number(env('MAX_INPUTS', 10)),
    maxResults: Number(env('MAX_RESULTS', 10)),
    searchPagesPerQuery: Number(env('SEARCH_PAGES_PER_QUERY', 1)),
    detailPagesPerItem: String(env('DETAIL_PAGES_PER_ITEM', 'true')).toLowerCase() !== 'false',
  },
  ml: {
    clientId: env('ML_CLIENT_ID', ''),
    clientSecret: env('ML_CLIENT_SECRET', ''),
    accessToken: env('ML_ACCESS_TOKEN', ''),
    refreshToken: env('ML_REFRESH_TOKEN', ''),
    apiBase: 'https://api.mercadolibre.com',
    authBase: 'https://api.mercadolibre.com/oauth/token',
  },
};
