const config = require('./config');

let tokenState = {
  accessToken: config.ml.accessToken,
  refreshToken: config.ml.refreshToken,
  expiresAt: 0,
};

function setTokenState(next) {
  tokenState = { ...tokenState, ...next };
}

function getTokenState() {
  return { ...tokenState };
}

function hasStaticCredentials() {
  return !!(config.ml.clientId && config.ml.clientSecret && tokenState.refreshToken);
}

async function refreshAccessToken() {
  if (!hasStaticCredentials()) {
    throw new Error('Missing Mercado Livre client credentials or refresh token.');
  }

  const body = {
    grant_type: 'refresh_token',
    client_id: config.ml.clientId,
    client_secret: config.ml.clientSecret,
    refresh_token: tokenState.refreshToken,
  };

  const response = await fetch(config.ml.authBase, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  const json = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`Token refresh failed (${response.status}): ${JSON.stringify(json)}`);
  }

  setTokenState({
    accessToken: json.access_token,
    refreshToken: json.refresh_token || tokenState.refreshToken,
    expiresAt: Date.now() + ((json.expires_in || 0) * 1000),
  });

  return getTokenState();
}

async function getAccessToken(forceRefresh = false) {
  if (forceRefresh || !tokenState.accessToken || (tokenState.expiresAt && Date.now() > tokenState.expiresAt - 60_000)) {
    await refreshAccessToken();
  }
  return tokenState.accessToken;
}

module.exports = {
  getAccessToken,
  refreshAccessToken,
  getTokenState,
};
