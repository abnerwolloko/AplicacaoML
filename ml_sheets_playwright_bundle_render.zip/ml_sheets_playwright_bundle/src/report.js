function brl(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return 'não visível';
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(value));
}

function computeStats(results) {
  const base = results.filter((x) => !x.kit && typeof x.price === 'number');
  if (!base.length) return { min: null, max: null, avg: null, strongestSeller: '' };
  const prices = base.map((x) => x.price);
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
  const strongest = [...base].sort((a, b) => {
    if ((b.soldQuantity || 0) !== (a.soldQuantity || 0)) return (b.soldQuantity || 0) - (a.soldQuantity || 0);
    return (a.price || 1e12) - (b.price || 1e12);
  })[0];
  return { min, max, avg, strongestSeller: strongest?.sellerNickname || strongest?.sellerId || '' };
}

function reportItem(anchor, ranked, diag) {
  const stats = computeStats(ranked);
  const rows = ranked.map((row, idx) => ({
    rank: idx + 1,
    title: row.title || 'não visível',
    seller: row.sellerNickname || 'não visível',
    marketplace: 'Mercado Livre',
    price: row.price,
    shipping: row.freeShipping ? 'Grátis' : 'não visível',
    totalEstimated: typeof row.price === 'number' ? row.price : null,
    soldOrProxy: row.soldQuantity ? `+${row.soldQuantity} vendidos` : row.soldText || 'não visível',
    reviews: row.reviewsTotal ?? 'não visível',
    rating: row.ratingAverage ?? 'não visível',
    url: row.permalink || row.url || 'não visível',
    observations: [
      row.top ? 'ALTA RELEVÂNCIA' : '',
      row.kit ? 'KIT/COMBO' : '',
      ...(row.matchReasons || []),
    ].filter(Boolean).join(' | ') || 'ok',
  }));

  return {
    anchor,
    stats,
    rows,
    executiveSummary: {
      product: anchor.title,
      gtin: anchor.gtin || 'não visível',
      brand: anchor.brand || 'não visível',
      model: anchor.model || 'não visível',
      itemsFound: rows.length,
      strongestSeller: stats.strongestSeller || 'não visível',
      minPrice: stats.min,
      avgPrice: stats.avg,
      maxPrice: stats.max,
      idealRange: stats.min && stats.avg ? { from: stats.min, to: stats.avg } : null,
    },
    diagnostics: diag,
  };
}

module.exports = {
  brl,
  computeStats,
  reportItem,
};
