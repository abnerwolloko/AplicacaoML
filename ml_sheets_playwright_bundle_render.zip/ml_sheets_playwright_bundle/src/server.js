const express = require('express');
const config = require('./config');
const { scrapeSearchResults, scrapeItemPage, parseItemPageSignals, extractItemId } = require('./scraper');
const { getItem, getItemsBatch, getUsersBatch, getSalePrice, searchBySeller } = require('./ml-api');
const { digits, detectModel, normalizeText } = require('./normalize');
const { chooseStrongest } = require('./matcher');
const { reportItem } = require('./report');

const app = express();
app.use(express.json({ limit: '1mb' }));

function requireApiKey(req, res, next) {
  if (!config.apiKey) return next();
  if (req.header('x-api-key') !== config.apiKey) return res.status(401).json({ error: 'invalid api key' });
  return next();
}

function parseInputUrl(url) {
  const decoded = decodeURIComponent(String(url || ''));
  const itemId = extractItemId(decoded);
  const catalog = decoded.match(/\/p\/(MLB\d+)/i)?.[1]?.toUpperCase() || '';
  const userProductId = decoded.match(/\/up\/(MLBU\d+)/i)?.[1]?.toUpperCase() || '';
  const slug = decoded
    .replace(/https?:\/\/[^/]+\//i, '')
    .split(/[?#]/)[0]
    .split('/')
    .filter(Boolean)
    .find((part) => /^[a-z0-9-]{15,}$/i.test(part) && !/^MLB/i.test(part) && !/^MLBU/i.test(part));
  return {
    itemId,
    catalogProductId: catalog,
    userProductId,
    slug: slug ? slug.replace(/-/g, ' ') : '',
  };
}

async function buildAnchor({ gtin, url }, diag) {
  const parsed = parseInputUrl(url);
  diag.anchor = { ...parsed };

  let item = null;
  if (parsed.itemId) {
    try {
      item = await getItem(parsed.itemId);
      diag.counters.itemDetails = (diag.counters.itemDetails || 0) + 1;
    } catch (error) {
      diag.warnings.push(`anchor_item_failed:${error.message}`);
    }
  }

  const title = item?.title || parsed.slug || '';
  return {
    inputUrl: url,
    gtin: digits(gtin) || item?.gtin || '',
    itemId: item?.itemId || parsed.itemId,
    catalogProductId: item?.catalogProductId || parsed.catalogProductId || '',
    categoryId: item?.categoryId || '',
    sellerId: item?.sellerId || null,
    title,
    brand: item?.brand || '',
    model: item?.model || detectModel(title),
    permalink: item?.permalink || url,
  };
}

function buildQueries(anchor) {
  const queries = [];
  const add = (value) => {
    const q = normalizeText(value).trim();
    if (!q || queries.includes(q)) return;
    queries.push(q);
  };
  if (anchor.gtin) add(anchor.gtin);
  if (anchor.model) {
    add(anchor.model);
    add(anchor.model.replace(/-/g, ' '));
    add(anchor.model.replace(/-/g, ''));
  }
  if (anchor.brand && anchor.model) add(`${anchor.brand} ${anchor.model}`);
  if (anchor.title) add(anchor.title);
  return queries.slice(0, 5);
}

async function enrichCandidates(rawCandidates, diag) {
  const itemIds = [...new Set(rawCandidates.map((x) => x.itemId).filter(Boolean))];
  const details = await getItemsBatch(itemIds);
  diag.counters.itemsBatch = (diag.counters.itemsBatch || 0) + 1;
  const detailMap = new Map(details.map((x) => [x.itemId, x]));
  const salePriceMap = new Map();

  for (const itemId of itemIds.slice(0, 15)) {
    const amount = await getSalePrice(itemId);
    if (amount !== null) salePriceMap.set(itemId, amount);
    diag.counters.salePrice = (diag.counters.salePrice || 0) + 1;
  }

  const sellerIds = [...new Set(details.map((x) => x.sellerId).filter(Boolean))];
  const users = await getUsersBatch(sellerIds);
  diag.counters.usersBatch = (diag.counters.usersBatch || 0) + 1;
  const userMap = new Map(users.map((x) => [x.id, x.nickname]));

  const enriched = [];
  for (const raw of rawCandidates) {
    const api = detailMap.get(raw.itemId) || {};
    const row = {
      itemId: raw.itemId || api.itemId || '',
      title: api.title || raw.title || '',
      permalink: api.permalink || raw.url || '',
      url: raw.url || api.permalink || '',
      sellerId: api.sellerId || null,
      sellerNickname: api.sellerNickname || userMap.get(api.sellerId) || raw.sellerNickname || '',
      price: salePriceMap.get(raw.itemId) ?? api.price ?? raw.price ?? null,
      freeShipping: typeof api.freeShipping === 'boolean' ? api.freeShipping : !!raw.freeShipping,
      soldQuantity: api.soldQuantity ?? null,
      soldText: raw.soldText || '',
      reviewsTotal: api.reviewsTotal ?? raw.reviewsTotal ?? null,
      ratingAverage: api.ratingAverage ?? raw.ratingAverage ?? null,
      categoryId: api.categoryId || '',
      catalogProductId: api.catalogProductId || '',
      gtin: api.gtin || raw.gtin || '',
      brand: api.brand || '',
      model: api.model || raw.detectedModel || '',
      detectedModel: raw.detectedModel || api.model || '',
      isCatalogListing: !!api.isCatalogListing,
      source: raw.source,
    };

    if (config.limits.detailPagesPerItem && (!row.price || !row.sellerNickname || !row.gtin || !row.model)) {
      try {
        const scraped = await scrapeItemPage(row.permalink || row.url);
        const signals = parseItemPageSignals(scraped);
        row.title = row.title || signals.title;
        row.sellerNickname = row.sellerNickname || signals.sellerNickname;
        row.price = row.price ?? signals.price;
        row.freeShipping = row.freeShipping || signals.freeShipping;
        row.soldText = row.soldText || signals.soldQuantityText;
        row.ratingAverage = row.ratingAverage ?? signals.ratingAverage;
        row.reviewsTotal = row.reviewsTotal ?? signals.reviewsTotal;
        row.detectedModel = row.detectedModel || signals.detectedModel;
        row.gtin = row.gtin || signals.gtin;
        diag.counters.itemHtml = (diag.counters.itemHtml || 0) + 1;
      } catch (error) {
        diag.warnings.push(`detail_html_failed:${row.itemId}:${error.message}`);
      }
    }

    enriched.push(row);
  }
  return enriched;
}

async function discoverByAnchorSeller(anchor, diag) {
  if (!anchor.sellerId) return [];
  try {
    const sellerSearch = await searchBySeller(anchor.sellerId, 50);
    diag.counters.anchorSellerSearch = (diag.counters.anchorSellerSearch || 0) + 1;
    return (sellerSearch.results || []).map((x) => ({
      source: 'anchor_seller_api',
      itemId: x.id,
      title: x.title || '',
      url: x.permalink || '',
      price: typeof x.price === 'number' ? x.price : null,
      freeShipping: !!x.shipping?.free_shipping,
      soldText: x.sold_quantity ? `+${x.sold_quantity} vendidos` : '',
      ratingAverage: x.reviews?.rating_average ?? null,
      reviewsTotal: x.reviews?.total ?? null,
      gtin: '',
      detectedModel: detectModel(x.title || ''),
    }));
  } catch (error) {
    diag.warnings.push(`anchor_seller_search_failed:${error.message}`);
    return [];
  }
}

async function analyzeOne(input) {
  const diag = { counters: {}, warnings: [], anchor: {} };
  const anchor = await buildAnchor(input, diag);
  const queries = buildQueries(anchor);
  diag.queries = queries;

  const htmlCandidates = await scrapeSearchResults(queries, 40);
  diag.counters.searchHtml = htmlCandidates.length;

  const sellerCandidates = await discoverByAnchorSeller(anchor, diag);
  const mergedRaw = [];
  const seen = new Set();
  for (const row of [
    { source: 'anchor', itemId: anchor.itemId, title: anchor.title, url: anchor.permalink, gtin: anchor.gtin, detectedModel: anchor.model },
    ...htmlCandidates,
    ...sellerCandidates,
  ]) {
    const key = row.itemId || row.url;
    if (!key || seen.has(key)) continue;
    seen.add(key);
    mergedRaw.push(row);
  }

  const enriched = await enrichCandidates(mergedRaw, diag);
  diag.counters.enriched = enriched.length;
  const { anchor: inferredAnchor, results } = chooseStrongest(anchor, enriched, config.limits.maxResults);
  diag.counters.finalApproved = results.length;

  return reportItem(inferredAnchor, results, diag);
}

app.get('/health', async (_req, res) => {
  res.json({ ok: true, service: 'ml-competitor-worker' });
});

app.post('/analyze', requireApiKey, async (req, res) => {
  try {
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    if (!items.length) return res.status(400).json({ error: 'items is required' });
    if (items.length > config.limits.maxInputs) return res.status(400).json({ error: `max ${config.limits.maxInputs} items` });

    const results = [];
    for (const item of items) {
      results.push(await analyzeOne(item));
    }
    return res.json({ ok: true, generatedAt: new Date().toISOString(), results });
  } catch (error) {
    return res.status(500).json({
      ok: false,
      error: error.message,
      stack: process.env.NODE_ENV === 'production' ? undefined : error.stack,
    });
  }
});

app.listen(config.port, () => {
  console.log(`Worker listening on :${config.port}`);
});
