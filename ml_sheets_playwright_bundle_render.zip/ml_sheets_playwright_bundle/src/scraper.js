const { chromium } = require('playwright');
const config = require('./config');
const { parseMoney, digits, detectModel, normalizeText } = require('./normalize');

function buildSearchUrl(query) {
  const url = new URL('https://lista.mercadolivre.com.br/');
  url.pathname += query.trim().replace(/\s+/g, '-');
  return url.toString();
}

function extractItemId(url) {
  const decoded = decodeURIComponent(String(url || ''));
  const byFilter = decoded.match(/item_id[:=](MLB\d+)/i);
  if (byFilter) return byFilter[1].toUpperCase();
  const plain = decoded.match(/\b(MLB\d{7,15})\b/i);
  return plain ? plain[1].toUpperCase() : '';
}

async function withBrowser(fn) {
  const browser = await chromium.launch({ headless: config.playwright.headless });
  const context = await browser.newContext({
    locale: 'pt-BR',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36',
  });
  const page = await context.newPage();
  page.setDefaultTimeout(config.playwright.timeoutMs);
  try {
    return await fn(page);
  } finally {
    await context.close();
    await browser.close();
  }
}

async function scrapeSearchResults(queries, maxCards = 30) {
  return withBrowser(async (page) => {
    const all = [];
    const seen = new Set();

    for (const query of queries) {
      const url = buildSearchUrl(query);
      await page.goto(url, { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1800);

      const cards = await page.evaluate(() => {
        const anchors = Array.from(document.querySelectorAll('a[href*="/MLB"], a[href*="/p/MLB"], a[href*="/up/MLBU"]'));
        return anchors.slice(0, 80).map((a) => {
          const card = a.closest('li, div, article') || a.parentElement || a;
          const block = card?.innerText || '';
          return {
            href: a.href,
            title: a.textContent || '',
            blockText: block,
          };
        });
      });

      for (const raw of cards) {
        const itemId = extractItemId(raw.href);
        const title = (raw.title || raw.blockText || '').replace(/\s+/g, ' ').trim();
        if (!itemId && !raw.href) continue;
        const key = itemId || raw.href;
        if (seen.has(key)) continue;
        seen.add(key);

        const block = raw.blockText || '';
        const price = parseMoney(block.match(/R\$\s?[\d\.]+,\d{2}/)?.[0] || '');
        const freeShipping = /frete gr[aá]tis/i.test(block);
        const sold = block.match(/\+?\d+[\d\.]*\s+vendid/i)?.[0] || '';
        const rating = block.match(/(\d+[\.,]\d)\s+de\s+5/i)?.[1] || null;
        const reviews = block.match(/\((\d+)\)/)?.[1] || null;

        all.push({
          source: 'search_html',
          query,
          itemId,
          url: raw.href,
          title,
          blockText: block,
          price,
          freeShipping,
          soldText: sold,
          ratingAverage: rating ? Number(String(rating).replace(',', '.')) : null,
          reviewsTotal: reviews ? Number(reviews) : null,
          detectedModel: detectModel(title + ' ' + block),
          gtin: digits(block),
        });

        if (all.length >= maxCards) return all;
      }
    }
    return all;
  });
}

async function scrapeItemPage(url) {
  return withBrowser(async (page) => {
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1500);
    return page.evaluate(() => {
      const text = document.body?.innerText || '';
      const jsonLd = Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
        .map((node) => node.textContent || '')
        .join('\n');
      return {
        title: document.querySelector('h1')?.textContent?.trim() || '',
        sellerNickname:
          document.querySelector('[data-testid="seller-link"]')?.textContent?.trim() ||
          document.querySelector('a[href*="/perfil/"]')?.textContent?.trim() ||
          '',
        text,
        jsonLd,
      };
    });
  });
}

function parseItemPageSignals(scraped) {
  const text = scraped?.text || '';
  return {
    title: scraped?.title || '',
    sellerNickname: scraped?.sellerNickname || '',
    price: parseMoney(text.match(/R\$\s?[\d\.]+,\d{2}/)?.[0] || ''),
    freeShipping: /frete gr[aá]tis/i.test(text),
    soldQuantityText: text.match(/\+?\d+[\d\.]*\s+vendid/i)?.[0] || '',
    ratingAverage: (() => {
      const match = text.match(/(\d+[\.,]\d)\s+de\s+5/);
      return match ? Number(match[1].replace(',', '.')) : null;
    })(),
    reviewsTotal: (() => {
      const match = text.match(/\((\d+)\)\s+opini/i);
      return match ? Number(match[1]) : null;
    })(),
    detectedModel: detectModel((scraped?.title || '') + ' ' + text),
    gtin: digits(text.match(/\b\d{8,14}\b/g)?.[0] || ''),
    rawText: normalizeText(text).slice(0, 4000),
  };
}

module.exports = {
  scrapeSearchResults,
  scrapeItemPage,
  parseItemPageSignals,
  extractItemId,
};
