const config = require('./config');
const { getAccessToken, refreshAccessToken } = require('./ml-auth');
const { digits, firstAttr } = require('./normalize');

async function apiJson(path, { params, retry401 = true } = {}) {
  const token = await getAccessToken(false);
  const url = new URL(path.startsWith('http') ? path : `${config.ml.apiBase}${path}`);
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.set(key, String(value));
      }
    });
  }

  const response = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
  });

  if (response.status === 401 && retry401) {
    await refreshAccessToken();
    return apiJson(path, { params, retry401: false });
  }

  const json = await response.json().catch(() => null);
  if (!response.ok) {
    const error = new Error(`Mercado Livre API ${response.status} on ${url.pathname}`);
    error.response = json;
    throw error;
  }
  return json;
}

function parseItemDetails(item) {
  const shipping = item?.shipping || {};
  const seller = item?.seller || {};
  const reviews = item?.reviews || {};
  const title = item?.title || '';

  return {
    itemId: item?.id || '',
    title,
    permalink: item?.permalink || '',
    sellerId: item?.seller_id || seller?.id || null,
    sellerNickname: seller?.nickname || '',
    price: typeof item?.price === 'number' ? item.price : null,
    originalPrice: typeof item?.original_price === 'number' ? item.original_price : null,
    freeShipping: !!shipping?.free_shipping,
    soldQuantity: typeof item?.sold_quantity === 'number' ? item.sold_quantity : null,
    categoryId: item?.category_id || '',
    catalogProductId: item?.catalog_product_id || '',
    gtin: digits(firstAttr(item, ['GTIN', 'EAN', 'UPC', 'ISBN', 'JAN'])),
    brand: firstAttr(item, ['BRAND']),
    model: firstAttr(item, ['MODEL']),
    reviewsTotal: typeof reviews?.total === 'number' ? reviews.total : null,
    ratingAverage: typeof reviews?.rating_average === 'number' ? reviews.rating_average : null,
    isCatalogListing: !!item?.catalog_listing,
  };
}

async function getItem(itemId) {
  const json = await apiJson(`/items/${itemId}`, { params: { include_attributes: 'all' } });
  return parseItemDetails(json);
}

async function getItemsBatch(itemIds) {
  if (!itemIds.length) return [];
  const json = await apiJson('/items', { params: { ids: itemIds.join(','), include_attributes: 'all' } });
  return json
    .filter((row) => row.code === 200 && row.body)
    .map((row) => parseItemDetails(row.body));
}

async function getUsersBatch(userIds) {
  if (!userIds.length) return [];
  const json = await apiJson('/users', { params: { ids: userIds.join(',') } });
  return json
    .filter((row) => row.code === 200 && row.body)
    .map((row) => ({ id: row.body.id, nickname: row.body.nickname || '' }));
}

async function getSalePrice(itemId) {
  try {
    const json = await apiJson(`/items/${itemId}/sale_price`, {
      params: { context: 'channel_marketplace' },
    });
    if (typeof json?.amount === 'number') return json.amount;
    if (typeof json?.sale_price?.amount === 'number') return json.sale_price.amount;
  } catch (_) {
    return null;
  }
  return null;
}

async function searchBySeller(sellerId, limit = 50) {
  return apiJson(`/sites/${config.siteId}/search`, { params: { seller_id: sellerId, limit } });
}

module.exports = {
  apiJson,
  getItem,
  getItemsBatch,
  getUsersBatch,
  getSalePrice,
  searchBySeller,
};
