function normalizeText(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s\-\/]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function digits(value) {
  return String(value || '').replace(/\D/g, '');
}

function firstAttr(item, ids) {
  const attrs = item?.attributes || [];
  const lookup = new Set(ids);
  for (const attr of attrs) {
    if (lookup.has(attr.id) && attr.value_name) return String(attr.value_name);
  }
  return '';
}

function detectModel(text) {
  const source = normalizeText(text).toUpperCase();
  const patterns = [
    /\b[A-Z]{1,6}-\d{2,8}[A-Z0-9-]*\b/g,
    /\b[A-Z]{2,8}\d{2,8}[A-Z0-9-]*\b/g,
  ];
  for (const regex of patterns) {
    const match = source.match(regex);
    if (match?.length) return match[0];
  }
  return '';
}

function tokenizeTitle(title) {
  const stop = new Set(['de', 'da', 'do', 'dos', 'das', 'e', 'com', 'sem', 'para', 'o', 'a', 'android']);
  return normalizeText(title)
    .split(' ')
    .filter(Boolean)
    .filter((token) => !stop.has(token));
}

function isKitLike(title) {
  const t = normalizeText(title);
  return ['kit', 'combo', 'par', '2 unidades', '3 unidades', 'chicote', 'camera de re', 'camara de re']
    .some((token) => t.includes(token));
}

function parseMoney(value) {
  if (!value) return null;
  const text = String(value).replace(/\./g, '').replace(/,/g, '.');
  const match = text.match(/(\d+(?:\.\d{1,2})?)/);
  return match ? Number(match[1]) : null;
}

module.exports = {
  normalizeText,
  digits,
  firstAttr,
  detectModel,
  tokenizeTitle,
  isKitLike,
  parseMoney,
};
