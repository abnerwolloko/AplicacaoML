const { normalizeText, tokenizeTitle, isKitLike, digits, detectModel } = require('./normalize');

function inferAnchor(anchor, candidates) {
  if (anchor.model && anchor.brand) return anchor;
  const firstStrong = candidates.find((c) => c.model || c.detectedModel || c.brand || c.gtin);
  return {
    ...anchor,
    brand: anchor.brand || firstStrong?.brand || '',
    model: anchor.model || firstStrong?.model || firstStrong?.detectedModel || detectModel(anchor.title || ''),
    gtin: anchor.gtin || firstStrong?.gtin || '',
  };
}

function overlapScore(anchorTitle, candidateTitle) {
  const a = tokenizeTitle(anchorTitle);
  const b = normalizeText(candidateTitle);
  if (!a.length) return 0;
  let hits = 0;
  for (const token of a) if (b.includes(token)) hits += 1;
  return Math.round((hits / a.length) * 25);
}

function validateCandidate(anchor, candidate) {
  let score = 0;
  const reasons = [];
  const anchorModel = normalizeText(anchor.model || detectModel(anchor.title || ''));
  const candidateModel = normalizeText(candidate.model || candidate.detectedModel || '');
  const anchorBrand = normalizeText(anchor.brand || '');
  const candidateBrand = normalizeText(candidate.brand || '');
  const anchorTitle = anchor.title || '';
  const candidateTitle = candidate.title || '';

  if (anchor.itemId && candidate.itemId === anchor.itemId) {
    return { ok: true, score: 999, reasons: ['anchor'] };
  }
  if (anchor.gtin && candidate.gtin && digits(candidate.gtin) === digits(anchor.gtin)) {
    score += 80;
    reasons.push('mesmo gtin');
  }
  if (anchor.catalogProductId && candidate.catalogProductId && candidate.catalogProductId === anchor.catalogProductId) {
    score += 75;
    reasons.push('mesmo catalogo');
  }
  if (anchorModel && candidateModel && anchorModel === candidateModel) {
    score += 60;
    reasons.push('mesmo modelo');
  }
  if (anchorBrand && candidateBrand && anchorBrand === candidateBrand) {
    score += 20;
    reasons.push('mesma marca');
  }
  if (anchor.categoryId && candidate.categoryId && anchor.categoryId === candidate.categoryId) {
    score += 12;
    reasons.push('mesma categoria');
  }

  const titlePts = overlapScore(anchorTitle, candidateTitle);
  score += titlePts;
  if (titlePts >= 10) reasons.push('titulo similar');

  const kit = isKitLike(candidateTitle);
  if (kit) {
    score -= 20;
    reasons.push('kit/combo');
  }

  const hardOk = Boolean(
    (anchor.gtin && candidate.gtin && digits(candidate.gtin) === digits(anchor.gtin)) ||
    (anchor.catalogProductId && candidate.catalogProductId && anchor.catalogProductId === candidate.catalogProductId) ||
    (anchorModel && candidateModel && anchorModel === candidateModel && (!anchorBrand || !candidateBrand || anchorBrand === candidateBrand))
  );

  const ok = hardOk || score >= 45;
  return { ok, score, reasons, kit };
}

function chooseStrongest(anchor, candidates, maxResults = 10) {
  const enrichedAnchor = inferAnchor(anchor, candidates);
  const scored = [];
  for (const candidate of candidates) {
    const verdict = validateCandidate(enrichedAnchor, candidate);
    if (!verdict.ok) continue;
    scored.push({
      ...candidate,
      matchScore: verdict.score,
      matchReasons: verdict.reasons,
      kit: verdict.kit,
      top: verdict.score >= 80 || (candidate.soldQuantity || 0) >= 50 || !!candidate.isCatalogListing,
    });
  }

  scored.sort((a, b) => {
    if (a.kit !== b.kit) return a.kit ? 1 : -1;
    if ((b.matchScore || 0) !== (a.matchScore || 0)) return (b.matchScore || 0) - (a.matchScore || 0);
    if ((b.soldQuantity || 0) !== (a.soldQuantity || 0)) return (b.soldQuantity || 0) - (a.soldQuantity || 0);
    return (a.price || 1e12) - (b.price || 1e12);
  });

  return { anchor: enrichedAnchor, results: scored.slice(0, maxResults) };
}

module.exports = {
  chooseStrongest,
  validateCandidate,
  inferAnchor,
};
