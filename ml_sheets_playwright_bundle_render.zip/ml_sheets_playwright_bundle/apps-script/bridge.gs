/**
 * Google Sheets bridge for the external Playwright worker.
 *
 * Script properties required:
 *   WORKER_BASE_URL  e.g. https://your-worker.example.com
 *   WORKER_API_KEY   optional but recommended
 */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Análise ML Externa')
    .addItem('Nova análise...', 'showExternalAnalysisDialog')
    .addSeparator()
    .addItem('Testar worker', 'testWorker')
    .addToUi();
}

function getBridgeConfig_() {
  var props = PropertiesService.getScriptProperties();
  return {
    baseUrl: String(props.getProperty('WORKER_BASE_URL') || '').replace(/\/$/, ''),
    apiKey: String(props.getProperty('WORKER_API_KEY') || '')
  };
}

function testWorker() {
  var cfg = getBridgeConfig_();
  if (!cfg.baseUrl) throw new Error('Defina WORKER_BASE_URL nas Script Properties.');
  var resp = UrlFetchApp.fetch(cfg.baseUrl + '/health', {
    method: 'get',
    muteHttpExceptions: true,
    headers: cfg.apiKey ? { 'x-api-key': cfg.apiKey } : {}
  });
  SpreadsheetApp.getUi().alert('Health ' + resp.getResponseCode() + ': ' + resp.getContentText());
}

function showExternalAnalysisDialog() {
  var html = HtmlService.createHtmlOutput(formHtml_())
    .setWidth(640)
    .setHeight(560);
  SpreadsheetApp.getUi().showModalDialog(html, 'Nova análise competitiva ML');
}

function runExternalAnalysis(items) {
  var cfg = getBridgeConfig_();
  if (!cfg.baseUrl) throw new Error('Defina WORKER_BASE_URL nas Script Properties.');
  if (!items || !items.length) throw new Error('Nenhum item enviado.');

  var resp = UrlFetchApp.fetch(cfg.baseUrl + '/analyze', {
    method: 'post',
    contentType: 'application/json',
    muteHttpExceptions: true,
    payload: JSON.stringify({ items: items }),
    headers: cfg.apiKey ? { 'x-api-key': cfg.apiKey } : {}
  });

  var code = resp.getResponseCode();
  var json = JSON.parse(resp.getContentText() || '{}');
  if (code < 200 || code >= 300 || !json.ok) {
    throw new Error((json && json.error) || ('Worker retornou HTTP ' + code));
  }

  writeReports_(json.results);
  return { ok: true, count: json.results.length };
}

function writeReports_(results) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  createIndex_(ss, results);
  results.forEach(function(result) {
    createTopSheet_(ss, result);
    createSummarySheet_(ss, result);
    createConclusionSheet_(ss, result);
    createDiagSheet_(ss, result);
  });
}

function safeDeleteSheet_(ss, name) {
  var sh = ss.getSheetByName(name);
  if (sh) ss.deleteSheet(sh);
}

function ensureSheet_(ss, name) {
  safeDeleteSheet_(ss, name);
  return ss.insertSheet(name);
}

function money_(n) {
  if (n === null || n === undefined || n === '' || isNaN(Number(n))) return 'não visível';
  return Utilities.formatString('R$ %.2f', Number(n)).replace('.', ',');
}

function createIndex_(ss, results) {
  var sh = ensureSheet_(ss, 'INDICE');
  sh.getRange(1,1,1,4).setValues([['GTIN','Produto','Qtd anúncios','Seller mais forte']]);
  var rows = results.map(function(r) {
    return [
      r.executiveSummary.gtin,
      r.executiveSummary.product,
      r.executiveSummary.itemsFound,
      r.executiveSummary.strongestSeller
    ];
  });
  if (rows.length) sh.getRange(2,1,rows.length,4).setValues(rows);
}

function createTopSheet_(ss, result) {
  var gtin = result.executiveSummary.gtin.replace(/\D/g, '') || 'SEM_GTIN';
  var sh = ensureSheet_(ss, 'TOP_' + gtin);
  sh.getRange(1,1,1,12).setValues([['#','Título','Vendedor','Marketplace','Preço atual','Frete','Preço total estimado','Qtd vendida/proxy','Avaliações','Nota','URL','Observações']]);
  var rows = result.rows.map(function(r) {
    return [r.rank, r.title, r.seller, r.marketplace, money_(r.price), r.shipping, money_(r.totalEstimated), r.soldOrProxy, r.reviews, r.rating, r.url, r.observations];
  });
  if (rows.length) sh.getRange(2,1,rows.length,12).setValues(rows);
}

function createSummarySheet_(ss, result) {
  var gtin = result.executiveSummary.gtin.replace(/\D/g, '') || 'SEM_GTIN';
  var sh = ensureSheet_(ss, 'RESUMO_' + gtin);
  var e = result.executiveSummary;
  var rows = [
    ['Produto', e.product],
    ['GTIN', e.gtin],
    ['Marca', e.brand],
    ['Modelo', e.model],
    ['Qtd anúncios', e.itemsFound],
    ['Seller mais forte', e.strongestSeller],
    ['Menor preço', money_(e.minPrice)],
    ['Preço médio', money_(e.avgPrice)],
    ['Maior preço', money_(e.maxPrice)],
    ['Faixa ideal', e.idealRange ? money_(e.idealRange.from) + ' a ' + money_(e.idealRange.to) : 'não visível']
  ];
  sh.getRange(1,1,rows.length,2).setValues(rows);
}

function createConclusionSheet_(ss, result) {
  var gtin = result.executiveSummary.gtin.replace(/\D/g, '') || 'SEM_GTIN';
  var sh = ensureSheet_(ss, 'CONCLUSAO_' + gtin);
  var e = result.executiveSummary;
  var text = [
    'Produto: ' + e.product,
    'Seller mais forte: ' + e.strongestSeller,
    'Faixa de preço: ' + money_(e.minPrice) + ' até ' + money_(e.maxPrice),
    'Preço médio: ' + money_(e.avgPrice),
    'Faixa ideal sugerida: ' + (e.idealRange ? money_(e.idealRange.from) + ' a ' + money_(e.idealRange.to) : 'não visível')
  ].join('\n');
  sh.getRange(1,1).setValue(text);
}

function createDiagSheet_(ss, result) {
  var gtin = result.executiveSummary.gtin.replace(/\D/g, '') || 'SEM_GTIN';
  var sh = ensureSheet_(ss, 'DIAG_' + gtin);
  var d = result.diagnostics || {};
  var rows = [
    ['Queries usadas', (d.queries || []).join(' | ')],
    ['Anchor item', d.anchor ? JSON.stringify(d.anchor) : '-'],
    ['Contadores', d.counters ? JSON.stringify(d.counters) : '-'],
    ['Avisos', d.warnings && d.warnings.length ? d.warnings.join(' | ') : '-']
  ];
  sh.getRange(1,1,rows.length,2).setValues(rows);
}

function formHtml_() {
  return '<!doctype html><html><body style="font-family:Arial;padding:16px">' +
    '<h3>Nova análise competitiva</h3>' +
    '<p>1 a 10 itens. Um por linha, no formato GTIN | URL</p>' +
    '<textarea id="txt" style="width:100%;height:260px"></textarea><br><br>' +
    '<button onclick="go()">Executar</button>' +
    '<script>' +
    'function go(){' +
    ' var lines=document.getElementById("txt").value.split(/\n+/).map(x=>x.trim()).filter(Boolean);' +
    ' var items=lines.map(function(line){ var p=line.split("|"); return { gtin:(p[0]||"").trim(), url:(p[1]||"").trim() }; });' +
    ' google.script.run.withSuccessHandler(function(){ google.script.host.close(); }).runExternalAnalysis(items);' +
    '}' +
    '<\/script></body></html>';
}
